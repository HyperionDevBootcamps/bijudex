from django.shortcuts import render
from django.http import HttpResponse
from .models import Bijuu

# Create your views here.


def home(request):
    bijuu = Bijuu.objects.all()
    context = {
        'bijuus': bijuu
    }
    return render(request, 'home.html', context)

def kurama(request):
    bijuus = Bijuu.objects.all()

    bijuu = Bijuu.objects.get(name='Kurama')
    context = {
        'bijuu': bijuu
    }
    return render(request, 'kurama.html', context)

def shukaku(request):
    bijuus = Bijuu.objects.all()

    bijuu = Bijuu.objects.get(name='Shukaku')
    context = {
        'bijuu': bijuu
    }
    return render(request, 'shukaku.html', context)

def matatabi(request):
    bijuus = Bijuu.objects.all()

    bijuu = Bijuu.objects.get(name='Matatabi')
    context = {
        'bijuu': bijuu
    }
    return render(request, 'matatabi.html', context)
