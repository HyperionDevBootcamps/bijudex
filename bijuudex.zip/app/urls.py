from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('kurama/', views.kurama, name='kurama'),
    path('shukaku/', views.shukaku, name='shukaku'),
    path('matatabi/', views.matatabi, name='matatabi'),
]